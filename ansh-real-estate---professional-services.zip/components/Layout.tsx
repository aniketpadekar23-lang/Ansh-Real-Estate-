
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Mail, MapPin, Instagram, Facebook, MessageCircle } from 'lucide-react';
import { SiteData } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  data: SiteData;
}

const Layout: React.FC<LayoutProps> = ({ children, data }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const { settings } = data;

  // SEO Sync Logic
  useEffect(() => {
    if (settings.metaTitle) {
      document.title = settings.metaTitle;
    } else {
      document.title = settings.siteName;
    }
    let metaDescription = document.querySelector('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.setAttribute('name', 'description');
      document.head.appendChild(metaDescription);
    }
    metaDescription.setAttribute('content', settings.metaDescription || '');
  }, [settings.metaTitle, settings.metaDescription, settings.siteName]);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Projects', path: '/projects' },
    { name: 'About Us', path: '/about' },
    { name: 'Services', path: '/services' },
    { name: 'Blog', path: '/blog' },
    { name: 'Contact Us', path: '/contact' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className="flex flex-col min-h-screen">
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md border-b border-slate-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-slate-900">
          <div className="flex justify-between items-center h-20">
            <Link to="/" className="flex flex-col">
              <span className="text-2xl font-bold tracking-tight">{settings.siteName}</span>
              <span className="text-[10px] uppercase tracking-widest text-slate-500 font-semibold -mt-1">Real Estate Services</span>
            </Link>

            <nav className="hidden md:flex space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`text-sm font-medium transition-colors hover:text-blue-600 ${isActive(link.path) ? 'text-blue-600' : 'text-slate-600'}`}
                >
                  {link.name}
                </Link>
              ))}
              <Link to="/admin" className="text-xs font-semibold px-3 py-1 bg-slate-100 text-slate-600 rounded-full hover:bg-slate-200 transition-colors">Admin</Link>
            </nav>

            <div className="md:hidden flex items-center">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="text-slate-600 hover:text-slate-900">
                {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
              </button>
            </div>
          </div>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-100 px-4 py-6 space-y-4 shadow-xl">
            {navLinks.map((link) => (
              <Link key={link.path} to={link.path} onClick={() => setIsMenuOpen(false)} className={`block text-lg font-medium ${isActive(link.path) ? 'text-blue-600' : 'text-slate-600'}`}>
                {link.name}
              </Link>
            ))}
          </div>
        )}
      </header>

      <main className="flex-grow">{children}</main>

      <footer className="bg-slate-900 text-slate-300 py-16">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-white">{settings.siteName}</h3>
            <p className="text-sm">Expert property consultancy serving the heart of Panvel and Raigad district.</p>
            <div className="flex space-x-4">
              <Facebook size={20} /><Instagram size={20} /><MessageCircle size={20} />
            </div>
          </div>
          <div className="space-y-4">
            <h4 className="text-white font-semibold">Our Projects</h4>
            <ul className="text-sm space-y-2">
              <li><Link to="/projects" className="hover:text-white">All Listings</Link></li>
              <li><Link to="/projects" className="hover:text-white">Pushpak Nagar</Link></li>
              <li><Link to="/projects" className="hover:text-white">Dapoli Sector 8</Link></li>
            </ul>
          </div>
          <div className="space-y-4">
            <h4 className="text-white font-semibold">Contact</h4>
            <p className="text-xs leading-relaxed">{settings.address}</p>
            <p className="text-xs">+{settings.phone1}</p>
          </div>
          <div className="space-y-4">
            <h4 className="text-white font-semibold">Proprietor</h4>
            <p className="text-sm font-semibold">{settings.ownerName}</p>
            <Link to="/contact" className="mt-4 inline-block bg-blue-600 text-white px-6 py-2 rounded-lg w-full text-center">Enquire</Link>
          </div>
        </div>
      </footer>
      <a href={`https://wa.me/${settings.phone1}`} target="_blank" rel="noopener" className="fixed bottom-8 right-8 z-50 bg-green-500 text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-all">
        <MessageCircle size={30} fill="currentColor" />
      </a>
    </div>
  );
};

export default Layout;
