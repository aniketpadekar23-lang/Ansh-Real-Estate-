
import React, { useState } from 'react';
import { SiteData, Enquiry } from '../types';
import { Phone, Mail, MapPin, Send, MessageCircle, CheckCircle, ArrowLeft, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useSiteStore } from '../store';

const Contact: React.FC<{ data: SiteData }> = ({ data }) => {
  const { settings } = data;
  const { addEnquiry } = useSiteStore();
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    purpose: 'Siddhivinayak Projects Inquiry',
    message: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSending(true);

    const newEnquiry: Enquiry = {
      id: Date.now().toString(),
      ...formData,
      date: new Date().toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }),
      status: 'new'
    };

    setTimeout(() => {
      addEnquiry(newEnquiry);
      setIsSending(false);
      setIsSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 1500);
  };

  if (isSubmitted) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center p-4">
        <div className="max-w-2xl w-full text-center space-y-10 animate-in fade-in zoom-in duration-500">
          <div className="inline-block p-6 rounded-full bg-green-50 text-green-500 mb-4">
            <CheckCircle size={64} strokeWidth={1.5} />
          </div>
          <div className="space-y-4">
            <h2 className="text-4xl font-bold font-serif text-slate-900 tracking-tight">Enquiry Sent!</h2>
            <p className="text-slate-500 text-lg">Your request has been registered. An auto-reply draft has been prepared for your records.</p>
          </div>
          
          <div className="bg-slate-50 p-8 md:p-12 rounded-[2.5rem] border border-slate-100 text-left relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 blur-3xl rounded-full"></div>
            <p className="text-slate-400 font-black uppercase tracking-[0.3em] text-[10px] mb-6">Auto-Reply Summary (Sent to {formData.email})</p>
            <div className="text-slate-700 whitespace-pre-wrap font-medium leading-relaxed text-sm md:text-base">
              {settings.autoReplyText}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 pt-6">
            <button 
              onClick={() => setIsSubmitted(false)}
              className="flex items-center space-x-2 text-slate-500 hover:text-slate-900 font-bold transition-colors"
            >
              <ArrowLeft size={18} />
              <span>Send Another Message</span>
            </button>
            <Link to="/" className="bg-blue-600 text-white px-10 py-5 rounded-2xl font-black text-lg hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/20">
              Return Home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  /**
   * REFINED GOOGLE MAP LOGIC:
   * We use a highly specific query to ensure the marker hits the exact Kolhi/Panvel location.
   * Including the building name 'Shree Krushna App' and landmark 'Manjula Nivas' significantly helps Google Maps.
   */
  const refinedSearchQuery = "Shree Krushna App., Manjula Nivas, Sector R3, Plot 243, Kolhi, Panvel, 410206";
  const mapSearchQuery = encodeURIComponent(refinedSearchQuery);
  const mapEmbedUrl = `https://maps.google.com/maps?q=${mapSearchQuery}&t=&z=16&ie=UTF8&iwloc=B&output=embed`;

  return (
    <div className="min-h-screen bg-slate-50/30">
      <section className="bg-slate-900 py-24 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="grid grid-cols-6 h-full w-full">
            {[...Array(36)].map((_, i) => <div key={i} className="border-[0.5px] border-white/20"></div>)}
          </div>
        </div>
        <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
          <h1 className="text-5xl md:text-7xl font-bold text-white font-serif mb-6 tracking-tighter">Connect With <span className="text-blue-500">Us</span></h1>
          <p className="text-slate-400 text-xl font-light max-w-2xl mx-auto">Get exclusive inventory details and architectural renders for all Panvel developments.</p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
            {/* Contact Info */}
            <div className="space-y-16">
              <div className="space-y-8">
                <h2 className="text-4xl font-bold font-serif text-slate-900">Direct Contacts</h2>
                <p className="text-slate-500 text-lg leading-relaxed">
                  Connect directly with Pravin Zuge for the most accurate and up-to-date pricing on Siddhivinayak projects.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-10">
                <a href={`tel:${settings.phone1}`} className="block p-10 bg-white rounded-[2.5rem] shadow-sm hover:shadow-2xl transition-all group border border-slate-100">
                  <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <Phone size={28} />
                  </div>
                  <h3 className="font-bold text-xl text-slate-900 mb-3">Call Support</h3>
                  <div className="space-y-1">
                    <p className="text-slate-500 font-bold">+{settings.phone1}</p>
                    <p className="text-slate-500 font-bold">+{settings.phone2}</p>
                  </div>
                </a>
                <a href={`mailto:${settings.email}`} className="block p-10 bg-white rounded-[2.5rem] shadow-sm hover:shadow-2xl transition-all group border border-slate-100">
                  <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-all">
                    <Mail size={28} />
                  </div>
                  <h3 className="font-bold text-xl text-slate-900 mb-3">Direct Email</h3>
                  <p className="text-slate-500 font-bold break-all text-xs sm:text-sm">{settings.email}</p>
                </a>
              </div>

              {/* Robust Map Display */}
              <div className="w-full h-[450px] md:h-[550px] rounded-[3rem] overflow-hidden shadow-2xl border-8 border-white bg-slate-100 transition-all duration-700 relative group">
                <div className="absolute inset-0 flex items-center justify-center -z-10 bg-slate-50">
                  <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
                </div>
                <div className="absolute top-6 left-6 z-20 bg-white/95 backdrop-blur-md px-6 py-4 rounded-2xl border border-slate-100 shadow-xl pointer-events-none transition-transform group-hover:translate-x-2">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-600 text-white rounded-xl flex items-center justify-center">
                      <MapPin size={20} />
                    </div>
                    <div>
                      <span className="text-[10px] font-black uppercase tracking-widest text-blue-600 block mb-1">Our Location</span>
                      <span className="text-xs font-bold text-slate-900">Shree Krushna App., Panvel</span>
                    </div>
                  </div>
                </div>
                <iframe
                  title="Ansh Real Estate Exact Location"
                  src={mapEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="relative z-10 w-full h-full grayscale-[0.1] group-hover:grayscale-0 transition-all duration-500"
                ></iframe>
              </div>
              
              <div className="p-8 bg-blue-600 rounded-[2.5rem] text-white shadow-2xl">
                 <div className="flex items-start space-x-4">
                    <div className="p-3 bg-white/10 rounded-xl">
                       <MapPin size={24} />
                    </div>
                    <div>
                       <h4 className="text-xl font-bold mb-2">Exact Address:</h4>
                       <p className="text-blue-50 leading-relaxed font-medium">
                          {settings.address}
                       </p>
                       <a 
                        href={`https://www.google.com/maps/search/?api=1&query=${mapSearchQuery}`} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="mt-4 inline-flex items-center space-x-2 text-white font-black text-xs uppercase tracking-[0.2em] border-b-2 border-white/30 pb-1 hover:border-white transition-all"
                       >
                          <span>Open in Google Maps App</span>
                          <ArrowLeft size={14} className="rotate-180" />
                       </a>
                    </div>
                 </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white p-10 md:p-16 rounded-[3rem] border border-slate-100 shadow-2xl space-y-12 h-fit sticky top-28">
              <div className="space-y-4">
                <h2 className="text-4xl font-bold font-serif text-slate-900 leading-tight">Priority Enquiry Form</h2>
                <p className="text-slate-500 font-medium text-sm">Fill out the form below to receive exclusive property renders and pricing details.</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Full Name</label>
                    <input 
                      type="text" 
                      required 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      placeholder="Ex: John Sharma" 
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-5 focus:ring-2 focus:ring-blue-600 outline-none transition-all font-bold" 
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Mobile Number</label>
                    <input 
                      type="tel" 
                      required 
                      value={formData.phone}
                      onChange={e => setFormData({...formData, phone: e.target.value})}
                      placeholder="+91" 
                      className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-5 focus:ring-2 focus:ring-blue-600 outline-none transition-all font-bold" 
                    />
                  </div>
                </div>
                
                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Email Address (For Auto-Reply)</label>
                  <input 
                    type="email" 
                    required 
                    value={formData.email}
                    onChange={e => setFormData({...formData, email: e.target.value})}
                    placeholder="yourname@domain.com" 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-5 focus:ring-2 focus:ring-blue-600 outline-none transition-all font-bold" 
                  />
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Enquiry Purpose</label>
                  <select 
                    value={formData.purpose}
                    onChange={e => setFormData({...formData, purpose: e.target.value})}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-5 focus:ring-2 focus:ring-blue-600 outline-none transition-all font-bold appearance-none"
                  >
                    <option>Siddhivinayak Projects Inquiry</option>
                    <option>Buying 1/2 BHK in Pushpak Nagar</option>
                    <option>Commercial Space Leasing</option>
                    <option>Consulting Request</option>
                  </select>
                </div>

                <div className="space-y-3">
                  <label className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Your Message</label>
                  <textarea 
                    rows={5} 
                    required 
                    value={formData.message}
                    onChange={e => setFormData({...formData, message: e.target.value})}
                    placeholder="Tell us more about your property needs..." 
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-6 py-5 focus:ring-2 focus:ring-blue-600 outline-none transition-all resize-none font-medium"
                  ></textarea>
                </div>

                <button 
                  type="submit" 
                  disabled={isSending}
                  className="w-full bg-slate-900 hover:bg-blue-600 disabled:bg-slate-400 text-white font-black py-6 rounded-2xl shadow-2xl transition-all flex items-center justify-center space-x-3 uppercase tracking-widest text-sm"
                >
                  {isSending ? (
                    <>
                      <Loader2 size={20} className="animate-spin" />
                      <span>Transmitting Enquiry...</span>
                    </>
                  ) : (
                    <>
                      <span>Send Enquiry</span>
                      <Send size={18} />
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
