
import React from 'react';
import { SiteData } from '../types';
import { Star, Quote } from 'lucide-react';

const Testimonials: React.FC<{ data: SiteData }> = ({ data }) => {
  const { testimonials } = data;

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-white py-24 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-6">
          <h1 className="text-4xl md:text-6xl font-bold font-serif text-slate-900">Client Feedback</h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg leading-relaxed">
            Our reputation is built on the success stories of our clients. Read how we've helped others find their perfect properties.
          </p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="columns-1 md:columns-2 lg:columns-3 gap-8 space-y-8">
            {testimonials.map((t) => (
              <div key={t.id} className="break-inside-avoid bg-white p-10 rounded-3xl border border-slate-100 shadow-sm hover:shadow-xl transition-all space-y-6">
                <div className="flex justify-between items-start">
                  <div className="flex">
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" className="text-amber-400" />
                    ))}
                  </div>
                  <Quote size={32} className="text-slate-100" />
                </div>
                <p className="text-slate-600 italic leading-relaxed text-lg">
                  "{t.content}"
                </p>
                <div className="flex items-center space-x-4 pt-4 border-t border-slate-50">
                  <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center font-bold">
                    {t.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900">{t.name}</h4>
                    <p className="text-xs text-slate-500 uppercase tracking-widest">{t.role}</p>
                  </div>
                </div>
              </div>
            ))}

            {testimonials.length === 0 && (
              <div className="col-span-full text-center py-24 text-slate-400">
                 <p className="text-xl">Sharing stories soon...</p>
              </div>
            )}
          </div>
        </div>
      </section>

      <section className="py-24 bg-blue-600 text-white">
        <div className="max-w-3xl mx-auto px-4 text-center space-y-8">
          <h2 className="text-3xl font-bold font-serif">Want to share your experience?</h2>
          <p className="text-blue-100 text-lg opacity-90">We value your feedback and would love to hear from you. Your insights help us grow and serve our community better.</p>
          <a href={`mailto:${data.settings.email}`} className="inline-block bg-white text-blue-600 px-10 py-4 rounded-2xl font-bold hover:bg-slate-50 transition-all">
            Submit Your Testimonial
          </a>
        </div>
      </section>
    </div>
  );
};

export default Testimonials;
