
import React, { useState } from 'react';
import { SiteData, SiteSettings, Service, Testimonial, BlogPost, Project, Enquiry } from '../types';
import { 
  Settings, Briefcase, Star, FileText, Plus, Trash2, Save, LogOut, 
  Layout as LayoutIcon, User, Phone, Info, Globe, Building2, 
  MailCheck, Home, AlignLeft, Inbox, Check, Mail, MessageSquare 
} from 'lucide-react';
import { useSiteStore } from '../store';

interface AdminDashboardProps {
  data: SiteData;
  updateSettings: (s: SiteSettings) => void;
  updateServices: (s: Service[]) => void;
  updateTestimonials: (t: Testimonial[]) => void;
  updateBlogs: (b: BlogPost[]) => void;
  updateProjects: (p: Project[]) => void;
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({
  data,
  updateSettings,
  updateServices,
  updateTestimonials,
  updateBlogs,
  updateProjects,
  onLogout
}) => {
  const { updateEnquiryStatus, deleteEnquiry } = useSiteStore();
  const [activeTab, setActiveTab] = useState<'general' | 'services' | 'enquiries' | 'blogs' | 'projects'>('enquiries');
  const [localSettings, setLocalSettings] = useState<SiteSettings>(data.settings);
  const [localProjects, setLocalProjects] = useState<Project[]>(data.projects);

  const saveSettings = () => {
    updateSettings(localSettings);
    alert("General settings updated successfully!");
  };

  const addProject = () => {
    const newProject: Project = {
      id: Date.now().toString(),
      name: "New Project",
      location: "Location here",
      developer: "Developer name",
      architect: "Architect name",
      image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800",
      status: "Available",
      type: "Residential"
    };
    const updated = [...localProjects, newProject];
    setLocalProjects(updated);
    updateProjects(updated);
  };

  const removeProject = (id: string) => {
    const updated = localProjects.filter(p => p.id !== id);
    setLocalProjects(updated);
    updateProjects(updated);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col md:flex-row">
      {/* Sidebar */}
      <aside className="w-full md:w-72 bg-slate-900 text-white p-6 flex flex-col shrink-0">
        <div className="mb-12 px-2">
          <div className="text-xl font-bold">Admin Console</div>
          <div className="text-xs text-slate-500 uppercase tracking-widest mt-1">Ansh Real Estate</div>
        </div>

        <nav className="space-y-2 flex-grow">
          <button
            onClick={() => setActiveTab('enquiries')}
            className={`w-full flex items-center justify-between px-4 py-3 rounded-xl transition-all ${activeTab === 'enquiries' ? 'bg-blue-600 shadow-lg shadow-blue-600/20' : 'text-slate-400 hover:bg-white/5'}`}
          >
            <div className="flex items-center space-x-3">
              <Inbox size={20} />
              <span>Enquiries</span>
            </div>
            {data.enquiries.filter(e => e.status === 'new').length > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                {data.enquiries.filter(e => e.status === 'new').length}
              </span>
            )}
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'projects' ? 'bg-blue-600 shadow-lg shadow-blue-600/20' : 'text-slate-400 hover:bg-white/5'}`}
          >
            <Building2 size={20} />
            <span>Projects Inventory</span>
          </button>
          <button
            onClick={() => setActiveTab('general')}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${activeTab === 'general' ? 'bg-blue-600 shadow-lg shadow-blue-600/20' : 'text-slate-400 hover:bg-white/5'}`}
          >
            <Settings size={20} />
            <span>General Settings</span>
          </button>
        </nav>

        <button onClick={onLogout} className="mt-12 flex items-center space-x-3 px-4 py-3 text-red-400 hover:bg-red-400/10 rounded-xl transition-all">
          <LogOut size={20} />
          <span>Logout</span>
        </button>
      </aside>

      {/* Main Area */}
      <main className="flex-grow p-8 md:p-12 overflow-y-auto max-h-screen">
        <div className="max-w-6xl mx-auto space-y-8 pb-20">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-slate-900 capitalize">{activeTab}</h1>
              <p className="text-slate-500 text-sm mt-1">Manage your website content and leads in real-time.</p>
            </div>
            {activeTab !== 'enquiries' && (
              <button onClick={saveSettings} className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-2xl font-bold flex items-center space-x-2 shadow-xl shadow-blue-600/30 transition-all active:scale-95">
                <Save size={18} />
                <span>Save Changes</span>
              </button>
            )}
          </div>

          {activeTab === 'enquiries' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              {data.enquiries.length === 0 ? (
                <div className="bg-white p-20 rounded-[3rem] border border-slate-200 text-center space-y-4">
                  <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto">
                    <Inbox size={40} className="text-slate-300" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900">No enquiries yet</h3>
                  <p className="text-slate-500">New leads from the contact form will appear here.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-6">
                  {data.enquiries.map((enquiry) => (
                    <div key={enquiry.id} className={`bg-white p-8 rounded-[2.5rem] border ${enquiry.status === 'new' ? 'border-blue-500 ring-4 ring-blue-500/5' : 'border-slate-200'} transition-all hover:shadow-xl`}>
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                        <div className="space-y-4 flex-grow">
                          <div className="flex items-center space-x-4">
                            <h3 className="text-2xl font-bold text-slate-900">{enquiry.name}</h3>
                            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${
                              enquiry.status === 'new' ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500'
                            }`}>
                              {enquiry.status}
                            </span>
                            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{enquiry.date}</span>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="flex items-center space-x-3 text-sm font-bold text-slate-600">
                              <Phone size={16} className="text-blue-500" />
                              <span>{enquiry.phone}</span>
                            </div>
                            <div className="flex items-center space-x-3 text-sm font-bold text-slate-600">
                              <Mail size={16} className="text-blue-500" />
                              <span className="truncate">{enquiry.email}</span>
                            </div>
                            <div className="flex items-center space-x-3 text-sm font-bold text-slate-600">
                              <LayoutIcon size={16} className="text-blue-500" />
                              <span>{enquiry.purpose}</span>
                            </div>
                          </div>

                          <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100">
                            <div className="flex items-center space-x-2 text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">
                              <MessageSquare size={14} />
                              <span>Client Message</span>
                            </div>
                            <p className="text-slate-700 leading-relaxed italic">"{enquiry.message}"</p>
                          </div>
                        </div>

                        <div className="flex flex-row lg:flex-col gap-3 shrink-0">
                          <button 
                            onClick={() => updateEnquiryStatus(enquiry.id, enquiry.status === 'replied' ? 'new' : 'replied')}
                            className={`p-4 rounded-2xl transition-all flex items-center justify-center ${
                              enquiry.status === 'replied' ? 'bg-green-100 text-green-600' : 'bg-blue-50 text-blue-600 hover:bg-blue-600 hover:text-white'
                            }`}
                            title="Mark as Replied"
                          >
                            <Check size={20} />
                          </button>
                          <a 
                            href={`mailto:${enquiry.email}`}
                            className="p-4 bg-slate-900 text-white rounded-2xl hover:bg-blue-600 transition-all flex items-center justify-center"
                            title="Reply via Email"
                          >
                            <Mail size={20} />
                          </a>
                          <button 
                            onClick={() => {
                              if(confirm('Are you sure you want to delete this lead?')) deleteEnquiry(enquiry.id);
                            }}
                            className="p-4 bg-red-50 text-red-600 rounded-2xl hover:bg-red-600 hover:text-white transition-all flex items-center justify-center"
                            title="Delete Lead"
                          >
                            <Trash2 size={20} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {activeTab === 'projects' && (
            <div className="space-y-6 animate-in fade-in duration-300">
              <button onClick={addProject} className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest flex items-center space-x-2 shadow-xl">
                <Plus size={20} />
                <span>Add New Project</span>
              </button>
              <div className="grid grid-cols-1 gap-8">
                {localProjects.map((p, index) => (
                  <div key={p.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-200 grid grid-cols-1 lg:grid-cols-4 gap-8 group hover:shadow-2xl transition-all">
                    <div className="lg:col-span-1">
                      <img src={p.image} className="w-full aspect-square object-cover rounded-3xl" />
                    </div>
                    <div className="lg:col-span-2 space-y-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Project Name</label>
                         <input 
                          value={p.name} 
                          onChange={e => {
                            const updated = [...localProjects];
                            updated[index].name = e.target.value;
                            setLocalProjects(updated);
                            updateProjects(updated);
                          }}
                          className="text-xl font-bold w-full outline-none border-b-2 border-slate-100 focus:border-blue-600 pb-1"
                        />
                      </div>
                      <div className="space-y-2">
                         <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Location</label>
                         <input 
                          value={p.location} 
                          onChange={e => {
                            const updated = [...localProjects];
                            updated[index].location = e.target.value;
                            setLocalProjects(updated);
                            updateProjects(updated);
                          }}
                          className="text-sm text-slate-500 w-full outline-none border-b-2 border-slate-100 focus:border-blue-600 pb-1"
                        />
                      </div>
                    </div>
                    <div className="flex flex-col justify-between items-end">
                      <button onClick={() => removeProject(p.id)} className="text-red-500 hover:bg-red-50 p-3 rounded-2xl transition-colors">
                        <Trash2 size={24} />
                      </button>
                      <select 
                        value={p.status}
                        onChange={e => {
                          const updated = [...localProjects]; updated[index].status = e.target.value as any; setLocalProjects(updated); updateProjects(updated);
                        }}
                        className="text-xs font-black uppercase border-2 rounded-xl px-4 py-3 w-full bg-slate-50 outline-none"
                      >
                        <option>Available</option>
                        <option>Sold Out</option>
                        <option>Upcoming</option>
                      </select>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'general' && (
             <div className="space-y-12 animate-in fade-in duration-300">
                <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-8">
                  <h3 className="text-xl font-bold flex items-center border-b pb-6"><Home className="mr-3 text-blue-600" /> Website Identity</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Business Name</label>
                      <input value={localSettings.siteName} onChange={e => setLocalSettings({...localSettings, siteName: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 outline-none font-bold" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Owner Name</label>
                      <input value={localSettings.ownerName} onChange={e => setLocalSettings({...localSettings, ownerName: e.target.value})} className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-6 py-4 outline-none font-bold" />
                    </div>
                  </div>
                </div>

                <div className="bg-white p-10 rounded-[2.5rem] border border-slate-200 shadow-sm space-y-10">
                  <h3 className="text-xl font-bold flex items-center border-b pb-6"><MailCheck className="mr-3 text-blue-600" /> Automated Enquiry Response</h3>
                  <div className="space-y-6">
                    <p className="text-sm text-slate-500 font-medium">This professional draft will be sent to clients immediately after form submission.</p>
                    <div className="space-y-3">
                        <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Auto-Reply Text Content</label>
                        <textarea
                          rows={12}
                          value={localSettings.autoReplyText}
                          onChange={e => setLocalSettings({...localSettings, autoReplyText: e.target.value})}
                          className="w-full border-2 bg-slate-50 p-6 rounded-2xl focus:ring-2 focus:ring-blue-500 outline-none transition-all font-medium text-slate-700 font-mono text-sm"
                        />
                      </div>
                  </div>
                </div>
              </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
