
import React, { useState, useRef, useEffect } from 'react';
import { SiteData, Project } from '../types';
import { MapPin, User, Building, Layout, ExternalLink, Box, X, Info, Phone, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

const ProjectModal: React.FC<{ project: Project; onClose: () => void }> = ({ project, onClose }) => {
  const [imgError, setImgError] = useState(false);

  // Close on ESC key
  useEffect(() => {
    const handleEsc = (e: ErrorEvent | KeyboardEvent) => {
      if ((e as KeyboardEvent).key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleEsc as any);
    return () => window.removeEventListener('keydown', handleEsc as any);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 animate-in fade-in duration-300">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-950/80 backdrop-blur-md"
        onClick={onClose}
      ></div>

      {/* Modal Content */}
      <div className="relative bg-white w-full max-w-5xl max-h-[90vh] overflow-y-auto rounded-[3rem] shadow-2xl flex flex-col md:flex-row animate-in zoom-in-95 duration-300">
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 p-3 bg-white/10 hover:bg-white/20 text-white md:text-slate-900 md:bg-slate-100 md:hover:bg-slate-200 rounded-full transition-all"
        >
          <X size={24} />
        </button>

        {/* Image Side */}
        <div className="w-full md:w-1/2 h-[300px] md:h-auto relative bg-slate-900">
          {!imgError ? (
            <img 
              src={project.image} 
              alt={project.name} 
              onError={() => setImgError(true)}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-white p-8">
              <Box size={48} className="text-blue-500 mb-4" />
              <p className="font-bold uppercase tracking-widest text-xs">Render Pending</p>
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 to-transparent"></div>
          <div className="absolute bottom-8 left-8">
            <span className="px-4 py-1.5 bg-blue-600 text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg">
              {project.status}
            </span>
          </div>
        </div>

        {/* Details Side */}
        <div className="w-full md:w-1/2 p-8 md:p-14 space-y-10">
          <div className="space-y-4">
            <h2 className="text-4xl md:text-5xl font-bold font-serif text-slate-900 leading-tight">
              {project.name}
            </h2>
            <div className="flex items-center space-x-3 text-blue-600 font-bold uppercase tracking-widest text-xs">
              <Building size={16} />
              <span>{project.type} Development</span>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-8">
            <div className="flex items-start space-x-5 group">
              <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-blue-600 shrink-0 border border-slate-100 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <MapPin size={20} />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Site Address</p>
                <p className="text-lg font-bold text-slate-800 leading-snug">{project.location}</p>
              </div>
            </div>

            <div className="flex items-start space-x-5 group">
              <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-blue-600 shrink-0 border border-slate-100 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <User size={20} />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Projected By</p>
                <p className="text-lg font-bold text-slate-800 leading-snug">{project.developer}</p>
              </div>
            </div>

            <div className="flex items-start space-x-5 group">
              <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center text-blue-600 shrink-0 border border-slate-100 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <Layout size={20} />
              </div>
              <div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Architecture</p>
                <p className="text-lg font-bold text-slate-800 leading-snug">{project.architect}</p>
              </div>
            </div>
          </div>

          {project.details && (
            <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100">
              <div className="flex items-center space-x-2 text-blue-600 mb-2">
                <Info size={16} />
                <span className="text-[10px] font-black uppercase tracking-widest">Additional Notes</span>
              </div>
              <p className="text-slate-600 text-sm leading-relaxed">{project.details}</p>
            </div>
          )}

          <div className="pt-8 border-t border-slate-100 flex flex-col sm:flex-row gap-4">
            <Link 
              to="/contact" 
              className="flex-1 bg-slate-900 text-white px-8 py-5 rounded-2xl font-black text-sm uppercase tracking-widest text-center hover:bg-blue-600 transition-all shadow-xl flex items-center justify-center space-x-2"
            >
              <Phone size={18} />
              <span>Contact Agent</span>
            </Link>
            <a 
              href="https://wa.me/919987404540" 
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 bg-green-500 text-white px-8 py-5 rounded-2xl font-black text-sm uppercase tracking-widest text-center hover:bg-green-600 transition-all shadow-xl flex items-center justify-center space-x-2"
            >
              <MessageCircle size={18} />
              <span>WhatsApp Details</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

const ProjectCard: React.FC<{ project: Project; onOpen: () => void }> = ({ project, onOpen }) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [rotate, setRotate] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    // Rotation values
    const rotateX = ((y - centerY) / centerY) * -15; 
    const rotateY = ((x - centerX) / centerX) * 15;
    
    setRotate({ x: rotateX, y: rotateY });
    setMousePos({ 
      x: (x / rect.width) * 100, 
      y: (y / rect.height) * 100 
    });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setRotate({ x: 0, y: 0 });
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={onOpen}
      className="group relative bg-white rounded-[2.5rem] overflow-hidden border border-slate-100 shadow-sm transition-all duration-300 cursor-pointer"
      style={{
        perspective: '1500px',
        transformStyle: 'preserve-3d',
        transform: `rotateX(${rotate.x}deg) rotateY(${rotate.y}deg) ${isHovered ? 'scale3d(1.05, 1.05, 1.05)' : 'scale3d(1, 1, 1)'}`,
        transition: isHovered ? 'none' : 'transform 0.8s cubic-bezier(0.23, 1, 0.32, 1), box-shadow 0.8s ease',
        boxShadow: isHovered 
          ? `${-rotate.y * 3}px ${rotate.x * 3}px 80px -20px rgba(15, 23, 42, 0.25)` 
          : '0 10px 40px -20px rgba(15, 23, 42, 0.05)'
      }}
    >
      <div className="relative h-[480px] overflow-hidden bg-slate-900" style={{ transformStyle: 'preserve-3d' }}>
        {/* Parallax Background Image */}
        {!imgError ? (
          <img
            src={project.image}
            alt={project.name}
            onError={() => setImgError(true)}
            className="w-full h-full object-cover transition-transform duration-1000 opacity-80 group-hover:opacity-100"
            style={{
              // Movement is opposite to rotation to create depth
              transform: `translateZ(-80px) scale(1.3) translateX(${rotate.y * -1.5}px) translateY(${rotate.x * 1.5}px)`,
              transition: isHovered ? 'none' : 'transform 1s cubic-bezier(0.23, 1, 0.32, 1), opacity 0.5s ease'
            }}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-12 text-center bg-slate-900 text-white relative">
             <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500 via-transparent to-transparent"></div>
             <Box size={64} className="text-blue-500 mb-6 animate-pulse" style={{ transform: 'translateZ(100px)' }} />
             <div style={{ transform: 'translateZ(80px)' }} className="space-y-2">
               <p className="text-blue-400 font-black uppercase tracking-[0.3em] text-xs">Project Status</p>
               <h4 className="text-2xl font-serif font-bold tracking-tight">Architectural Render <br/> Coming Soon</h4>
               <p className="text-slate-500 text-sm mt-4 italic">{project.name}</p>
             </div>
          </div>
        )}
        
        {/* Dynamic Light/Shine Effect */}
        <div 
          className="absolute inset-0 pointer-events-none opacity-0 group-hover:opacity-30 transition-opacity duration-300 mix-blend-soft-light"
          style={{ 
            background: `radial-gradient(circle at ${mousePos.x}% ${mousePos.y}%, rgba(255,255,255,1), transparent 50%)`,
            transform: 'translateZ(150px)'
          }}
        />

        {/* Content Overlays with different Z-depths */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/30 to-transparent opacity-90"></div>
        
        <div className="absolute top-8 left-8" style={{ transform: 'translateZ(120px)' }}>
          <span className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-[0.2em] backdrop-blur-2xl shadow-2xl border border-white/20 ${
            project.status === 'Available' ? 'bg-green-500/90 text-white' : 'bg-blue-600/90 text-white'
          }`}>
            {project.status}
          </span>
        </div>

        <div className="absolute bottom-12 left-10 right-10 text-white space-y-4" style={{ transform: 'translateZ(100px)' }}>
          <div className="space-y-2">
            <h3 className="text-4xl font-bold font-serif leading-none tracking-tight drop-shadow-2xl">{project.name}</h3>
            <div className="flex items-center space-x-3 text-sm text-blue-300/80">
              <MapPin size={16} />
              <span className="font-bold uppercase tracking-widest">{project.location}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-10 space-y-10 bg-white" style={{ transform: 'translateZ(40px)' }}>
        <div className="grid grid-cols-2 gap-8">
          <div className="space-y-2 border-l-4 border-blue-600 pl-5">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Projected By</p>
            <p className="text-sm font-black text-slate-900 line-clamp-1">{project.developer}</p>
          </div>
          <div className="space-y-2 border-l-4 border-blue-600 pl-5">
            <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em]">Architecture</p>
            <p className="text-sm font-black text-slate-900 line-clamp-1">{project.architect}</p>
          </div>
        </div>

        <div className="flex items-center justify-between pt-8 border-t border-slate-50">
          <div className="flex items-center space-x-4">
            <Building size={20} className="text-blue-600" />
            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">{project.type}</span>
          </div>
          <div 
            className="flex items-center space-x-3 bg-slate-900 text-white px-8 py-4 rounded-[1.2rem] text-xs font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl"
          >
            <span>View Details</span>
            <ExternalLink size={16} />
          </div>
        </div>
      </div>
    </div>
  );
};

const Projects: React.FC<{ data: SiteData }> = ({ data }) => {
  const { projects } = data;
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);

  // Disable body scroll when modal is open
  useEffect(() => {
    if (selectedProject) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
  }, [selectedProject]);

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Dynamic Header */}
      <section className="bg-slate-900 py-36 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-blue-600/10 blur-[180px] rounded-full translate-x-1/2 -translate-y-1/2"></div>
        <div className="max-w-7xl mx-auto px-4 text-center relative z-10">
          <h1 className="text-6xl md:text-9xl font-bold text-white font-serif mb-10 tracking-tighter">Current <span className="text-blue-500 italic">Portfolio</span></h1>
          <p className="text-slate-400 max-w-2xl mx-auto text-xl leading-relaxed font-light">
            Experience our premium property builds through an interactive 3D showcase. Click any card to explore specifications and architecture.
          </p>
        </div>
      </section>

      {/* Grid of Projects */}
      <section className="py-32 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 md:gap-24">
          {projects.map((project) => (
            <ProjectCard 
              key={project.id} 
              project={project} 
              onOpen={() => setSelectedProject(project)} 
            />
          ))}
        </div>
      </section>

      {/* Modal */}
      {selectedProject && (
        <ProjectModal 
          project={selectedProject} 
          onClose={() => setSelectedProject(null)} 
        />
      )}

      {/* Footer CTA */}
      <section className="py-32 bg-slate-900 relative overflow-hidden">
        <div className="absolute bottom-0 left-0 w-full h-full bg-[radial-gradient(circle_at_bottom,_var(--tw-gradient-stops))] from-blue-900/20 via-transparent to-transparent"></div>
        <div className="max-w-4xl mx-auto px-4 text-center space-y-12 relative z-10">
          <h2 className="text-5xl md:text-7xl font-bold font-serif text-white tracking-tight">Secure Your Unit Today.</h2>
          <p className="text-slate-400 text-2xl font-light">
            Expert assistance for all Siddhivinayak properties. Floor plans and site visits available on request.
          </p>
          <div className="pt-8">
            <Link 
              to="/contact" 
              className="inline-flex items-center space-x-6 bg-blue-600 text-white px-16 py-6 rounded-[2.5rem] font-black text-xl shadow-2xl hover:bg-blue-700 hover:scale-105 transition-all"
            >
              <span>Connect with Pravin Zuge</span>
              <ExternalLink size={24} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Projects;
