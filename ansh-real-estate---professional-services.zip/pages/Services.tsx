
import React from 'react';
import { SiteData } from '../types';
import { Home, Key, Briefcase, TrendingUp, Gavel, Search, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const iconMap: { [key: string]: any } = {
  Home,
  Key,
  Briefcase,
  TrendingUp,
  Gavel,
  Search
};

const Services: React.FC<{ data: SiteData }> = ({ data }) => {
  const { services } = data;

  return (
    <div className="min-h-screen bg-slate-50">
      <section className="bg-white py-24 border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-6">
          <h1 className="text-4xl md:text-6xl font-bold font-serif text-slate-900">Our Expertise</h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg leading-relaxed">
            From first-time homebuyers to seasoned commercial investors, we provide tailored strategies to achieve your real estate goals.
          </p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service) => {
            const Icon = iconMap[service.icon] || Home;
            return (
              <div key={service.id} className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100 hover:shadow-2xl hover:-translate-y-2 transition-all flex flex-col group">
                <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-8 group-hover:bg-blue-600 group-hover:text-white transition-all">
                  <Icon size={32} />
                </div>
                <h3 className="text-2xl font-bold mb-4 text-slate-900 group-hover:text-blue-600 transition-colors">{service.title}</h3>
                <p className="text-slate-500 leading-relaxed mb-8 flex-grow">
                  {service.description}
                </p>
                <Link to="/contact" className="inline-flex items-center space-x-2 text-blue-600 font-bold group-hover:translate-x-2 transition-transform">
                  <span>Enquire Now</span>
                  <ArrowRight size={18} />
                </Link>
              </div>
            );
          })}

          <div className="bg-blue-600 p-10 rounded-3xl shadow-xl flex flex-col justify-center text-white space-y-6">
            <h3 className="text-3xl font-bold font-serif">Need Custom Solutions?</h3>
            <p className="text-blue-100 opacity-90">
              We understand that every property journey is unique. Contact us for a personalized consultation tailored to your specific requirements.
            </p>
            <Link to="/contact" className="bg-white text-blue-600 px-8 py-3 rounded-xl font-bold text-center hover:bg-slate-50 transition-colors">
              Request Call Back
            </Link>
          </div>
        </div>
      </section>

      <section className="py-24 bg-slate-900 text-white">
        <div className="max-w-5xl mx-auto px-4 text-center space-y-12">
          <h2 className="text-3xl font-bold font-serif">Our Service Process</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {[
              { step: "01", title: "Consultation", desc: "Understanding your needs and budget." },
              { step: "02", title: "Site Visits", desc: "Curating and visiting the best options." },
              { step: "03", title: "Closure", desc: "Negotiation, legal work, and keys." }
            ].map((item, i) => (
              <div key={i} className="space-y-4">
                <div className="text-5xl font-bold text-white/10">{item.step}</div>
                <h4 className="text-xl font-bold">{item.title}</h4>
                <p className="text-slate-400 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Services;
