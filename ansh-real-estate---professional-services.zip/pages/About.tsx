
import React from 'react';
import { SiteData } from '../types';
import { Target, Eye, Award, CheckCircle } from 'lucide-react';

const About: React.FC<{ data: SiteData }> = ({ data }) => {
  const { settings } = data;

  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <section className="bg-slate-900 py-24">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white font-serif mb-6">Our Legacy & Commitment</h1>
          <p className="text-slate-400 max-w-2xl mx-auto text-lg">Founded on principles of integrity and excellence, we are your local partners in real estate.</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
            <div className="space-y-8">
              <div className="bg-blue-50 p-10 rounded-3xl space-y-6">
                <h2 className="text-3xl font-bold text-slate-900 font-serif">Who We Are</h2>
                <p className="text-slate-600 leading-relaxed text-lg">
                  {settings.aboutContent}
                </p>
                <div className="pt-4 flex items-center space-x-4">
                  <img
                    src="https://picsum.photos/seed/owner/100/100"
                    alt={settings.ownerName}
                    className="w-16 h-16 rounded-full grayscale"
                  />
                  <div>
                    <div className="font-bold text-slate-900 text-xl">{settings.ownerName}</div>
                    <div className="text-sm text-slate-500">Proprietor, Ansh Real Estate</div>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="p-8 border border-slate-100 rounded-3xl shadow-sm hover:shadow-md transition-shadow">
                  <Target className="text-blue-600 mb-4" size={32} />
                  <h3 className="font-bold text-xl mb-2">Our Mission</h3>
                  <p className="text-slate-500 text-sm">{settings.mission}</p>
                </div>
                <div className="p-8 border border-slate-100 rounded-3xl shadow-sm hover:shadow-md transition-shadow">
                  <Eye className="text-blue-600 mb-4" size={32} />
                  <h3 className="font-bold text-xl mb-2">Our Vision</h3>
                  <p className="text-slate-500 text-sm">{settings.vision}</p>
                </div>
              </div>
            </div>

            <div className="space-y-12">
              <h2 className="text-3xl font-bold font-serif text-slate-900">Why Choose Us?</h2>
              <div className="space-y-8">
                {[
                  { title: "Local Market Mastery", desc: "Unmatched understanding of Panvel and Raigad neighborhoods." },
                  { title: "Client-Centric Philosophy", desc: "Your goals are our priority. We listen, then we deliver." },
                  { title: "Transparency", desc: "Clear communication, no hidden costs, and honest advice." },
                  { title: "Legal Expertise", desc: "Expert handling of titles, taxes, and government registrations." }
                ].map((item, i) => (
                  <div key={i} className="flex items-start space-x-6">
                    <div className="bg-blue-600 text-white p-2 rounded-full mt-1">
                      <CheckCircle size={20} />
                    </div>
                    <div>
                      <h4 className="font-bold text-xl text-slate-900 mb-1">{item.title}</h4>
                      <p className="text-slate-500">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-slate-900 text-white p-10 rounded-3xl shadow-2xl space-y-6">
                <Award size={40} className="text-blue-400" />
                <h3 className="text-2xl font-bold">A Legacy of Trust</h3>
                <p className="text-slate-400 leading-relaxed">
                  "Over the past 15 years, we haven't just sold properties; we've built homes and helped businesses grow. Our success is measured by the smiles of our clients and the strength of our community."
                </p>
                <p className="font-serif italic text-blue-400">— {settings.ownerName}</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
