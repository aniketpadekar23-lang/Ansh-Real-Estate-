
import React from 'react';
import { SiteData } from '../types';
import { Calendar, User, Tag, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Blog: React.FC<{ data: SiteData }> = ({ data }) => {
  const { blogs } = data;

  return (
    <div className="min-h-screen bg-white">
      <section className="bg-slate-50 py-24">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-4">
          <h1 className="text-4xl md:text-6xl font-bold font-serif text-slate-900">Real Estate Insights</h1>
          <p className="text-slate-500 max-w-xl mx-auto">Latest trends, guides, and news from the Panvel and Raigad property market.</p>
        </div>
      </section>

      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {blogs.map((post) => (
              <article key={post.id} className="group flex flex-col h-full bg-white border border-slate-100 rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all">
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-blue-600 text-white text-xs font-bold uppercase tracking-widest px-4 py-2 rounded-lg backdrop-blur-md">
                      {post.category}
                    </span>
                  </div>
                </div>
                <div className="p-8 flex flex-col flex-grow space-y-4">
                  <div className="flex items-center space-x-4 text-slate-400 text-xs">
                    <span className="flex items-center"><Calendar size={14} className="mr-1" /> {post.date}</span>
                    <span className="flex items-center"><User size={14} className="mr-1" /> Admin</span>
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-tight">
                    {post.title}
                  </h2>
                  <p className="text-slate-500 text-sm leading-relaxed flex-grow">
                    {post.excerpt}
                  </p>
                  <div className="pt-4 border-t border-slate-50">
                    <Link to={`/blog/${post.slug}`} className="inline-flex items-center space-x-2 text-blue-600 font-bold group">
                      <span>Read Article</span>
                      <ArrowRight size={18} className="group-hover:translate-x-2 transition-transform" />
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {blogs.length === 0 && (
            <div className="text-center py-24 text-slate-400">
              <p className="text-xl">No articles found. Check back soon!</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Blog;
