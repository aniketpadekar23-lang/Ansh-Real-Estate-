
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronRight, ShieldCheck, MapPin, ArrowUpRight, Phone, Building2, Building } from 'lucide-react';
import { SiteData } from '../types';

const Home: React.FC<{ data: SiteData }> = ({ data }) => {
  const { settings, services, projects } = data;
  
  // Only use the provided projects
  const featuredProjects = projects.slice(0, 3);

  return (
    <div className="space-y-0">
      {/* Hero Section */}
      <section className="relative h-[90vh] flex items-center overflow-hidden bg-slate-900">
        <div className="absolute inset-0 z-0 opacity-40">
           {/* Visual background that doesn't distract from the projects */}
           <div className="absolute inset-0 bg-gradient-to-br from-blue-900/40 to-transparent"></div>
           <div className="grid grid-cols-8 h-full w-full opacity-10">
              {[...Array(64)].map((_, i) => (
                <div key={i} className="border-[0.5px] border-white/20"></div>
              ))}
           </div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <div className="max-w-4xl space-y-10 animate-in fade-in slide-in-from-bottom-12 duration-1000">
            <div className="inline-flex items-center space-x-3 bg-blue-600/30 border border-blue-400/40 px-5 py-2 rounded-full text-xs font-black uppercase tracking-[0.2em] backdrop-blur-xl">
              <MapPin size={16} className="text-blue-400" />
              <span>Real Estate Panvel & Raigad</span>
            </div>
            <h1 className="text-6xl md:text-8xl font-black font-serif leading-[0.9] tracking-tighter">
              Discover Your <br/><span className="text-blue-500">Future Home.</span>
            </h1>
            <p className="text-xl md:text-2xl text-slate-300 leading-relaxed font-light max-w-2xl">
              {settings.heroSubtitle}
            </p>
            <div className="flex flex-wrap gap-6 pt-6">
              <Link to="/projects" className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-5 rounded-2xl font-black text-lg transition-all flex items-center space-x-3 group shadow-2xl shadow-blue-600/40">
                <span>Browse Inventory</span>
                <ChevronRight className="group-hover:translate-x-2 transition-transform" />
              </Link>
              <Link to="/contact" className="bg-white/5 hover:bg-white/10 border border-white/20 backdrop-blur-md text-white px-10 py-5 rounded-2xl font-black text-lg transition-all">
                Contact Agent
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Stats */}
      <section className="bg-white py-16 border-b border-slate-50">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-2 md:grid-cols-4 gap-12">
          {[
            { label: 'Market Experience', val: '15+ Yrs' },
            { label: 'Active Projects', val: '20+' },
            { label: 'Client Satisfaction', val: '100%' },
            { label: 'Region Expertise', val: 'Raigad' }
          ].map((stat, i) => (
            <div key={i} className="text-center group">
              <div className="text-4xl font-black text-slate-900 mb-2 group-hover:text-blue-600 transition-colors">{stat.val}</div>
              <div className="text-[10px] uppercase tracking-[0.3em] text-slate-400 font-black">{stat.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Projects - SHOWING ONLY PROVIDED IMAGES */}
      <section className="py-32 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
            <div className="max-w-2xl space-y-6">
              <h2 className="text-blue-600 font-black uppercase tracking-[0.4em] text-xs">Architectural Highlights</h2>
              <p className="text-5xl md:text-6xl font-bold font-serif text-slate-900 tracking-tight">Featured Buildings</p>
            </div>
            <Link to="/projects" className="bg-white text-slate-900 border border-slate-200 px-8 py-4 rounded-2xl font-black flex items-center hover:bg-slate-900 hover:text-white transition-all shadow-xl shadow-slate-200/50">
              Explore All 17 Projects <ArrowUpRight size={20} className="ml-2" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {featuredProjects.map((project) => (
              <div key={project.id} className="group bg-white rounded-[2.5rem] overflow-hidden shadow-sm hover:shadow-2xl transition-all border border-slate-100 flex flex-col h-full">
                <div className="relative h-72 overflow-hidden bg-slate-200">
                  {/* Pattern placeholder if user hasn't uploaded local image yet */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-20">
                     <Building size={80} />
                  </div>
                  <img src={project.image} className="w-full h-full object-cover transition-transform group-hover:scale-110 relative z-10" />
                  <div className="absolute top-6 left-6 z-20">
                    <span className="bg-blue-600 text-white text-[10px] font-black uppercase tracking-widest px-4 py-1.5 rounded-full shadow-lg">
                      {project.status}
                    </span>
                  </div>
                </div>
                <div className="p-10 space-y-6 flex-grow flex flex-col">
                  <h3 className="text-2xl font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{project.name}</h3>
                  <div className="flex items-center text-slate-500 font-medium">
                    <MapPin size={16} className="mr-2 text-blue-500" />
                    {project.location}
                  </div>
                  <div className="pt-8 mt-auto border-t border-slate-50 flex justify-between items-center">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{project.developer}</span>
                    <Link to="/projects" className="text-blue-600 text-xs font-black uppercase tracking-widest hover:translate-x-1 transition-transform inline-flex items-center">
                       Details <ChevronRight size={14} />
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10">
            {services.map((service) => (
              <div key={service.id} className="bg-white p-10 rounded-[2.5rem] border border-slate-50 hover:border-blue-100 hover:shadow-2xl hover:shadow-blue-600/5 transition-all group">
                <div className="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center mb-8 group-hover:bg-blue-600 transition-colors">
                  <ShieldCheck size={28} />
                </div>
                <h3 className="text-xl font-bold mb-4 text-slate-900">{service.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed font-medium">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* High-CTA Contact Section */}
      <section className="py-40 bg-slate-900 relative overflow-hidden">
         <div className="absolute inset-0 bg-blue-600/5"></div>
         <div className="max-w-5xl mx-auto px-4 text-center space-y-12 relative z-10">
            <h2 className="text-5xl md:text-7xl font-bold font-serif text-white tracking-tight">Direct Path to <span className="text-blue-500">Ownership.</span></h2>
            <p className="text-slate-400 text-2xl font-light max-w-3xl mx-auto leading-relaxed">
               Specialized in high-value transactions for the Pushpak Nagar sector. Connect with Pravin Zuge for exclusive insights.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-8 pt-8">
               <a href={`tel:${settings.phone1}`} className="bg-white text-slate-900 px-12 py-6 rounded-[2rem] font-black text-xl hover:bg-blue-600 hover:text-white transition-all shadow-2xl w-full sm:w-auto flex items-center justify-center space-x-4">
                  <Phone size={24} />
                  <span>+{settings.phone1}</span>
               </a>
               <Link to="/contact" className="bg-blue-600 text-white px-12 py-6 rounded-[2rem] font-black text-xl hover:bg-blue-700 transition-all shadow-2xl shadow-blue-600/20 w-full sm:w-auto">
                  Request Portfolio
               </Link>
            </div>
         </div>
      </section>
    </div>
  );
};

export default Home;
